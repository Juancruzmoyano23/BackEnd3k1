package org.frc.utn.service.todo.ap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoApApplicationTests {

	@Test
	void contextLoads() {
	}

}
