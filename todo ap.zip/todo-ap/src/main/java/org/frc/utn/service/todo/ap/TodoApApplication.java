package org.frc.utn.service.todo.ap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoApApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoApApplication.class, args);
	}

}
