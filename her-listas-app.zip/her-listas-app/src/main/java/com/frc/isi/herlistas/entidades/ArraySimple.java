package com.frc.isi.herlistas.entidades;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArraySimple<E> implements Iterable<E> {

    private E[] items;
    private int posicion;

    public ArraySimple() {
        this(10);
    }

    public ArraySimple(int size) {
        this.items = new Object[size];
        posicion = 0;
    }

    public int size() {
        return this.items.length;
    }

    public Object get(int pos) throws NoSuchElementException {
        if (pos >= this.items.length)
            throw new NoSuchElementException("get: No se puede retornar un elemento que no existe");
        return this.items[pos];
    }

    public void set(E item, int posicion) throws IllegalAccessException {
        if (posicion >= this.items.length)
            throw new IllegalAccessException(
                    "set: No puedo insertar una valor en una poscion inexistente del conjunto");

        this.items[posicion] = item;
    }

    public void append(E item) {
        if (posicion >= this.items.length)
            this.asegurarCapacidad();

        this.items[posicion] = item;
        posicion++;
    }

    public Object remove(int pos) throws NoSuchElementException {
        if (pos >= this.items.length)
            throw new NoSuchElementException("remove: No existe el elemento a eliminar");

        Object deleted = this.items[pos];
        this.items[pos] = null;
        this.mantenerIntegridad(pos);
        return deleted;
    }

    private void mantenerIntegridad(int pos) {
        Object[] nuevo = new Object[this.size() - 1];
        System.arraycopy(this.items, 0, nuevo, 0, pos);
        System.arraycopy(this.items, pos + 1, nuevo, pos, this.size() - pos - 1);
        this.items = nuevo;
    }

    private void asegurarCapacidad() {

        Object[] nuevo = new Object[this.items.length * 2];
        System.arraycopy(this.items, 0, nuevo, 0, this.items.length);
        this.items = (E[]) nuevo;
    }

    @Override
    public Iterator<E> iterator() {
        return new IteradorArray<>();
    }

    // Clase que me da la herramienta para recorrer items
    private class IteradorArray<E> implements Iterator<E> {
        private int size;
        private int current;

        public IteradorArray() {
            size = items.length;
            current = 0;
        }

        @Override
        public boolean hasNext() {
            return current < size;
        }

        @Override
        public E next() {
            E proximo = (E) items[current];
            current++;
            return proximo;
        }

    }

}
