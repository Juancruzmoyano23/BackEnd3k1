package com.frc.isi.herlistas.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ListaPrecio {
    private int codigo;
    private String descripcion;
    private double precioUnitario;
    private double descuento;

    public double precioConDescunto() {
        return precioUnitario - (precioUnitario * descuento);
    }
}
