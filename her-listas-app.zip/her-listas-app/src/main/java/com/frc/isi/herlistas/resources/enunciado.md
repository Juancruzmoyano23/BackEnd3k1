# Enunciado manejo de Stream y Colecciones

### Caso de Estudio - Comercio electricidad

Una empresa que vende productos para construcción en seco necesita un programa para optimizar sus operaciones diarias, para ello nos presenta un archivo csv llamado [productos.csv](../resources/files/productos.csv) con la información necesaria para realizar las estadísticas necesarias. Las cuales deben estar disponibles a leccion del usuario en un menu de opciones (No es broma, pero va a tener un twist).

A continuación detallamos las entidades que se necesitan implementar para llevar a cabo el trabajo.

```mermaid
classDiagram
    class Producto {
        -String codigo
        -String descripcion
        -Integer stock
        -ListaPrecio listasPrecio
        +importeVentaPrecioLista()
    }
    class Pintura {
        -Integer litros
    }
    class MuroSeco {
        -Boolean esPerfilAcero
        -Double metros
    }
    class ListaPrecio {
        -Integer     codigo
        -String descripcion
        -Boolean isActive
        -Double precioUnitario
        -Double descuento
        +calcularPrecioACobrar()
    }
    Producto <|-- Pintura
    Producto <|-- MuroSeco
    Producto "1"--> ListaPrecio
```
Realizar las siguiente operaciones:
1. Cargar los productos y listas de precios en memoria, si la lista de precio esta presente en varios productos usar la misma.
    > URL location = App.class.getResource("[nombre de archivo csv]");
    >
    > URL folderPath = App.class.getResource("/files");
