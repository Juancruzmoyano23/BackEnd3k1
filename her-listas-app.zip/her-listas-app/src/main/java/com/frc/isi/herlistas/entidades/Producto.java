package com.frc.isi.herlistas.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class Producto implements Comparable {

    private String codigo;
    private String descripcion;
    private int stock;
    protected ListaPrecio listaPrecio;

    public abstract double importeVentaPrecioLista();

}
