package com.frc.isi.herlistas.app;

import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import com.frc.isi.herlistas.entidades.*;

public class App {
    public static void main(String[] args) {
        ArraySimple<Producto> productos = new ArraySimple<Producto>();

        URL location = App.class.getResource("productos.csv");

        try (Scanner lector = new Scanner(new File(location.toURI()))) {
            lector.nextLine();
            while (lector.hasNextLine()) {
                String linea = lector.nextLine();
                String[] items = linea.split(",");

                String codigo = items[1];
                String desc = items[2];
                int stock = Integer.parseInt(items[3]);

                String lp = items[7].split("|")[0];
                lp = lp.replaceAll("[", lp);
                lp = lp.replaceAll("]", lp);
                String[] dlp = lp.split(",");
                ListaPrecio listaPrecio = new ListaPrecio(Integer.parseInt(dlp[0]), dlp[1],
                        Double.parseDouble(dlp[2]), Double.parseDouble(dlp[3]));

                Producto p;
                String tipo = items[0];
                if (tipo.equalsIgnoreCase("pintura")) {
                    int litros = Integer.parseInt(items[4]);
                    p = new Pintura(codigo, desc, stock, listaPrecio, litros);
                } else {
                    double metros = Double.parseDouble(items[5]);
                    boolean pa = "1".equals(items[6]);
                    p = new MuroSeco(codigo, desc, stock, listaPrecio, metros, pa);
                }
                productos.append(p);
                // Ver todos los productos
                Iterator<Producto> it = productos.iterator();
                while (it.hasNext()) {
                    System.out.println(it.next());
                }

                // Ver el total de lo precios de ventas - acumular
                double total = 0;
                for (Producto prod : productos) {
                    total += prod.importeVentaPrecioLista();
                }

            }
        } catch (FileNotFoundException | URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}