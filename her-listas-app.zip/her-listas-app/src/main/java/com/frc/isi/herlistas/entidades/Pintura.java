package com.frc.isi.herlistas.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@AllArgsConstructor
public class Pintura extends Producto {

    private int litros;

    @Override
    public int compareTo(Object o) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
    }

    @Override
    public double importeVentaPrecioLista() {
        return listaPrecio.precioConDescunto() * litros;
    }

    public Pintura(String codigo, String desc, int stock, ListaPrecio listaPrecio, int litros2) {
        super(codigo, desc, stock, listaPrecio);
        this.litros = litros2;
    }

}
