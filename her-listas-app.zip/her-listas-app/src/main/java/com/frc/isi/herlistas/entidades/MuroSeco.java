package com.frc.isi.herlistas.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MuroSeco extends Producto {

    private boolean perfilAcero;
    private double metros;

    @Override
    public int compareTo(Object o) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
    }

    @Override
    public double importeVentaPrecioLista() {
        return listaPrecio.precioConDescunto() * metros;
    }

    public MuroSeco(String codigo, String desc, int stock, ListaPrecio listaPrecio, double metros2, boolean pa) {
        super(codigo, desc, stock, listaPrecio);
        this.metros = metros2;
        this.perfilAcero = perfilAcero;
    }
}
