# Enunciado manejo de Stream y Colecciones

### Caso de Estudio - Comercio electricidad

Una empresa que vende productos para construcción en seco necesita un programa para optimizar sus operaciones diarias, para ello nos presenta un archivo csv llamado [productos.csv](../resources/files/productos.csv) con la información necesaria para realizar las estadísticas necesarias. Las cuales deben estar disponibles a leccion del usuario en un menu de opciones (No es broma, pero va a tener un twist).

A continuación detallamos las entidades que se necesitan implementar para llevar a cabo el trabajo.

```mermaid
classDiagram
    class Producto {
        -String codigo
        -String descripcion
        -Integer stock
        -ListaPrecio[] listasPrecios
        +importeVentaPrecioLista(int codigo)
    }
    class Pintura {
        -Integer litros
    }
    class MuroSeco {
        -Boolean esPerfilAcero
        -Double metros
    }
    class ListaPrecio {
        -Integer     codigo
        -String descripcion
        -Boolean isActive
        -Double precioUnitario
        -Double descuento
        +calcularPrecioACobrar()
    }
    Producto <|-- Pintura
    Producto <|-- MuroSeco
    Producto "1"--> ListaPrecio
```
Realizar las siguiente operaciones:
1. Cargar los productos y listas de precios en memoria, si la lista de precio esta presente en varios productos usar la misma.
    > URL location = App.class.getResource("[nombre de archivo csv]");
    >
    > URL folderPath = App.class.getResource("/files");
2. Mostar todos los productos cuyo stock sea mayor al promedio de stock de todos los productos
3. Mostar un informe de con la descripcion de la lista de precios y la cantidad de productos en la que está. Ordenado por la descripcion de la lista de precios
4. Mostrar un informe con todo aquellos productos que son Pinturas incluyendo el precio de venta de ese producto, considerando que el precio unitario de la lista de precios es por un 1 Litro de pintura. (De alguna forma obtener el id de esa lista de precios)
    > importe de venta = precio unitario * listros - descuento (si s aplicable)
5. Determinar el Producto que tiene la maxima y la minima cantidad de stock disponible.
6. Informar para los Producto de MuroSeco cuales son perfiles de acero, y si esa cantidad es mayor al resto de los productos de MuroSeco

Se deben usar colecciones y stream, con programación funcional. Maneje excepciones donde considere necesario.